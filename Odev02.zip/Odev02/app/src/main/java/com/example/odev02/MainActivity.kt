package com.example.odev02

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textView : TextView = findViewById(R.id.textView)
        val textView4 : TextView = findViewById(R.id.textView4)
        val textView3 : TextView = findViewById(R.id.textView3)
        val zarImage : ImageView = findViewById(R.id.zarImage)
        val zarImage2 : ImageView = findViewById(R.id.zarImage2)
        val buttonAt : Button = findViewById(R.id.buttonAt)
        val buttonTemizle : Button = findViewById(R.id.buttonTemizle)

        buttonAt.setOnClickListener {

            val randomSayi = (1..6).random()
            val randomSayi2 = (1..6).random()
            textView.text = randomSayi.toString()
            textView3.text = randomSayi2.toString()

            when(randomSayi){
                1 -> zarImage.setImageResource(R.drawable.dice_1)
                2 -> zarImage.setImageResource(R.drawable.dice_2)
                3 -> zarImage.setImageResource(R.drawable.dice_3)
                4 -> zarImage.setImageResource(R.drawable.dice_4)
                5 -> zarImage.setImageResource(R.drawable.dice_5)
                6 -> zarImage.setImageResource(R.drawable.dice_6)
            }
            when(randomSayi2){
                1 -> zarImage2.setImageResource(R.drawable.dice_1)
                2 -> zarImage2.setImageResource(R.drawable.dice_2)
                3 -> zarImage2.setImageResource(R.drawable.dice_3)
                4 -> zarImage2.setImageResource(R.drawable.dice_4)
                5 -> zarImage2.setImageResource(R.drawable.dice_5)
                6 -> zarImage2.setImageResource(R.drawable.dice_6)
            }
        }

        buttonTemizle.setOnClickListener {
            var x = 1

            if (x == 1){
                zarImage.setImageResource((R.drawable.empty_dice))
                textView.setText("")

                zarImage2.setImageResource((R.drawable.empty_dice))
                textView3.setText("")

                textView4.setText("")
            }

        }
    }


}

/*
Basıldığında tepki veren 2 tuş bulunacak
# Her düğme için bir tane olmak üzere iki tıklama işleyici ayarlamalıdır.
# 1. Tuşun üzerinde  ZAR AT yazılacak ve basıldığında rastgele 2 zar atacak (2 zar da her atıldığında aynı değeri göstermemeli) zarlar image olarak ekranda gösterilecek
# 2. Tuş üzerinde  TEMİZLE  yazılacak ve basıldığında ekranı temizleyecek veya üstünde değer olmayan zarları gösterecek
# Zar kullanımında when yapısı kullanılacak
# Ödev yüklerken github link kullanılacak
*/