package com.example.sayitahminoyunu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.textfield.TextInputEditText
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var puan = 100
        var randomSayi = (1..6).random()

        buttonTahmin.setOnClickListener {

            puan -= 1
            val tahminsayi = tahmin.text.toString().toInt()

            if(tahminsayi < randomSayi){
                sayi.text = "Daha Büyük Bir Sayı Dene"
                skor.text = "Skorunuz : $puan"
            }

            if(tahminsayi > randomSayi){
                sayi.text = "Daha Küçük Bir Sayı Dene"
                skor.text = "Skorunuz : $puan"
            }

            if(tahminsayi == randomSayi){
                sayi.text = "Tebrikler Bildiniz Skorunuz : $puan"
                skor.text = " "
                buttonTahmin.isClickable = false
            }

            if (puan == 0){
                sayi.text = "Kaybettiniz Tekrar Dene !"
                skor.text = "Skorunuz : $puan"
                buttonTahmin.isClickable = false
            }
        }
    }
}